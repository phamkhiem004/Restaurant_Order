import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { CreatePaymentDto } from './dto/create-payment.dto';
import { UpdatePaymentDto } from './dto/update-payment.dto';
import { Payment } from './entities/payment.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { DiningTable } from 'src/dining-tables/entities/dining-table.entity';
import { Order } from 'src/orders/entities/order.entity';
import { CreatePaymentRecordDto } from './dto/create-payment-record.dto';

@Injectable()
export class PaymentsService {

  constructor(
    @InjectRepository(Payment) private paymentRepository: Repository<Payment>,
    @InjectRepository(Order) private orderRepository: Repository<Order>,
    @InjectRepository(DiningTable) private tableRepository: Repository<DiningTable>,
  ) {}

  async createPendingPayment(dto: CreatePaymentRecordDto): Promise<number> {
    // Tìm đơn hàng dựa trên orderId từ DTO
    const order = await this.orderRepository.findOne({ 
      where: { id: dto.orderId } 
    });
    
    if (!order) {
      throw new NotFoundException(`Không tìm thấy đơn hàng #${dto.orderId}`);
    }
    if (order.status === 'PAID') {
      throw new BadRequestException('Đơn hàng này đã được thanh toán trước đó');
    }

    // Tạm thời chuyển trạng thái đơn hàng sang 'BILLED' (Đang xử lý tính tiền / Khóa order)
    order.status = 'BILLED' as any;
    await this.orderRepository.save(order);

    // Lấy số tiền chuẩn từ Database (Chuyển sang kiểu số an toàn)
    const finalAmount = Math.round(Number(order.totalAmount));

    // Tạo bản ghi lưu vết lịch sử giao dịch thanh toán
    // Giải quyết triệt để lỗi đỏ TypeORM: Truyền cả object order & ép kiểu amount thành chuỗi (.toString())
    const paymentLog = this.paymentRepository.create({
      orderId: order.id,                          // Truyền thực thể Order thay vì trường order_id
      paymentMethod: dto.paymentMethod as any, // Gán 'VNPAY' từ DTO sạch
      amount: finalAmount.toString(),        // Khớp kiểu dữ liệu string/decimal trong entity của bạn
      status: 'PENDING' as any,
      vnpTxnRef: dto.vnpTxnRef,
    });
    
    await this.paymentRepository.save(paymentLog);
    
    return finalAmount; // Trả về số tiền thực tế để VNPAY làm cổng băm dữ liệu mã hóa URL
  }

  /**
   * 2. Hàm gạch nợ hệ thống khi nhận được phản hồi IPN Webhook ngầm từ VNPAY
   */
  async processPaymentResult(txnRef: string, transactionNo: string, responseCode: string) {
    const payment = await this.paymentRepository.findOne({
      where: { vnpTxnRef: txnRef }
    });

    if (!payment) return { RspCode: '01', Message: 'Order not found' };
    if (payment.status !== 'PENDING') return { RspCode: '02', Message: 'Order already confirmed' };

    // Vì không dùng relations, ta phải query thủ công bảng Order ra
    const order = await this.orderRepository.findOne({
      where: { id: payment.orderId }
    });

    if (responseCode === '00') {
      // THÀNH CÔNG
      payment.status = 'SUCCESS';
      payment.transactionId = transactionNo; // Khớp với biến transactionId
      await this.paymentRepository.save(payment);

      if (order) {
        order.status = 'PAID' as any;
        await this.orderRepository.save(order);

        // Giả sử bảng Order của bạn lưu id bàn ăn là tableId (hoặc table_id)
        // Nếu tên biến trong entity order của bạn khác, hãy sửa lại chữ tableId cho khớp nhé
        const tableId = (order as any).tableId; 
        if (tableId) {
          const table = await this.tableRepository.findOne({ where: { id: tableId } });
          if (table) {
            table.status = 'AVAILABLE' as any;
            await this.tableRepository.save(table);
          }
        }
      }
    } else {
      // THẤT BẠI
      payment.status = 'FAILED';
      payment.transactionId = transactionNo;
      await this.paymentRepository.save(payment);

      if (order) {
        order.status = 'SERVED' as any; 
        await this.orderRepository.save(order);
      }
    }

    return { RspCode: '00', Message: 'Confirm success' };
  }
  create(createPaymentDto: CreatePaymentDto) {
    console.log(createPaymentDto);
    return 'This action adds a new payment';
  }

  findAll() {
    return `This action returns all payments`;
  }

  findOne(id: number) {
    return `This action returns a #${id} payment`;
  }

  update(id: number, updatePaymentDto: UpdatePaymentDto) {
    console.log(updatePaymentDto);
    return `This action updates a #${id} payment`;
  }

  remove(id: number) {
    return `This action removes a #${id} payment`;
  }
}
