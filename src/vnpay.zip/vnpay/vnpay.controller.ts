import { Controller, Get, Req, Res, Query, ParseIntPipe } from '@nestjs/common';
import { VnpayService } from './vnpay.service';
import express from 'express';
import { CreateVnpayUrlDto } from './dto/create-vnpay-url.dto';
import { VnpayIpnQueryDto } from './dto/vnpay-ipn-query.dto';

@Controller('vnpay')
export class VnpayController {
  constructor(private readonly vnpayService: VnpayService) {}


  /**
   * 1. API Tạo URL Thanh toán
   */
  @Get('create-payment-url')
  async createPaymentUrl(
    @Req() req: express.Request,
    // 👇 Sử dụng DTO ở đây để tự động validate orderId (kiểm tra rỗng, kiểm tra số âm...)
    @Query() queryDto: CreateVnpayUrlDto 
  ) {
    const paymentUrl = await this.vnpayService.createPaymentUrl(req, queryDto.orderId);
    
    return {
      message: 'Tạo URL thanh toán thành công',
      url: paymentUrl
    };
  }

  /**
   * 2. API Trả về giao diện sau khi thanh toán
   */
  @Get('vnpay-return')
  vnpayReturn(@Query() query: any, @Res() res: express.Response) {
    const isVerified = this.vnpayService.verifySecureHash(query);
    
    if (!isVerified) {
      return res.send('<h1>❌ Lỗi bảo mật: Chữ ký không hợp lệ!</h1>');
    }

    if (query.vnp_ResponseCode === '00') {
      return res.send('<h1>🎉 Thanh toán thành công! Bàn ăn đã được giải phóng.</h1>');
    } else {
      return res.send(`<h1>⚠️ Thanh toán thất bại hoặc đã hủy (Mã lỗi: ${query.vnp_ResponseCode})</h1>`);
    }
  }

  /**
   * 3. API Webhook IPN chạy ngầm
   */
  @Get('vnpay-ipn')
  async vnpayIpn(
    // 👇 Sử dụng DTO ở đây để đảm bảo VNPAY server phải gửi đủ các trường bắt buộc
    @Query() queryDto: VnpayIpnQueryDto
  ) {
    try {
      // Vì DTO cho phép [key: string]: any nên ta vẫn có thể truyền toàn bộ object này vào service
      return await this.vnpayService.handleIpn(queryDto);
    } catch (error) {
      console.error('IPN Error:', error);
      return { RspCode: '99', Message: 'Unknown error' };
    }
  }
}
