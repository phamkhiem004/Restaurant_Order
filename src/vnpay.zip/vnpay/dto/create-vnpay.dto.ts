export class CreateVnpayDto {}
