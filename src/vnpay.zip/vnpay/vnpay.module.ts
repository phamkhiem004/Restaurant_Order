import { Module } from '@nestjs/common';
import { VnpayService } from './vnpay.service';
import { VnpayController } from './vnpay.controller';
import { Payment } from 'src/payments/entities/payment.entity';
import { Order } from 'src/orders/entities/order.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Order, Payment])],
  controllers: [VnpayController],
  providers: [VnpayService],
})
export class VnpayModule {}
